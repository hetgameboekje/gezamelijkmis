print("U gaat dalijk 3 getallen opnoemen die gaan door elkaar gedeeld worden.")
getal = int(input("noem een getal "))
getal2 = int(input("noem een getal "))
getal3 = int(input("noem een getal "))

print("Hier de getallen gedeeld door elkaar:")
antwoord = (getal / getal2 / getal3)
uitkomst = round(antwoord,4)
print(uitkomst)
