print("Hoe oud ben je?")
leeftijd = int(input())
if leeftijd >= 18 :
    print("Je mag autorijden.")
else: print("Je mag geen autorijden.")