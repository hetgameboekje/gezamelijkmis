import datetime
now = datetime.datetime.now()
now
datetime.datetime(2009, 1, 6, 15, 8, 24, 78915)
print(now)


print("waneer bent u geboren?")
datum = input("Zet de datum dag/maand/jaar ")
if datum >= now:
    print()
else: print()
