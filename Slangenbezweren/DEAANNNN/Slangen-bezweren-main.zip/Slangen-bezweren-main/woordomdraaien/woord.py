print("Vul een woord in dit woord gaat gespiegeld worden.")
woord = input()[::-1]
print(woord)
